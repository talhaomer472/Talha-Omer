---
title: "Mathematics, Statistics and Econometrics (ECNM11002)."
collection: teaching
type: "<b>Postgraduate</b> course"
permalink: /teaching/econ
venue: "University of Edinburgh"
excerpt: ""
semesters: "Winter 2019"
coauthors: 
location: "Edinburgh"
---

3 week intensive preparation course for the MSc degree of the Scottish Graduate Programme in Economics (~80 students).
