---
title: "The Economy."
collection: teaching
type: "<b>Undergraduate</b> course"
permalink: /teaching/ts
venue: "Heriot-Watt University"
excerpt: ""
semesters: "Winter 2019"
coauthors: 
location: "Edinburgh"
---

Teaching Assistant for "The Economy": 1st year undergraduate economics course (Micro & Macro topics).
