---
title: "Introductory Econometrics."
collection: teaching
type: "<b>Undergraduate</b> course"
permalink: /teaching/ts
venue: "Heriot-Watt University"
excerpt: ""
semesters: "Winter 2020"
coauthors: 
location: "Edinburgh"
---

Teaching Assistant for "Introductory Econometrics": 3rd year undergraduate course. Taught using Stata.
