---
title: "Econometrics 2 (ECNM11050)."
collection: teaching
type: "<b>Postgraduate</b> course"
permalink: /teaching/ts
venue: "University of Edinburgh"
excerpt: ""
semesters: "Winter 2019-Winter2022"
coauthors: 
location: "Edinburgh"
---

MSc level course on time series econometrics for the Scottish Graduate Programme in Economics (~80 students).
